Author: *Daniele Zambon*,  
Affiliation: *Università della Svizzera italiana*  
eMail: `daniele.zambon@usi.ch`  
Last Update: *25/05/2018*   


# Experiments of article:  

Zambon, Daniele, Lorenzo Livi, and Cesare Alippi.   
__Anomaly and Change Detection in Graph Streams through Constant-Curvature Manifold Embeddings.__   
_IEEE International Joint Conference on Neural Networks_ (2018).   

## Instructions
* Install the `cdg` module available [here](https://github.com/dan-zam/cdg) (works with cdg version 2.0 and python3.)
* If not already present, obtain the `graph-matching-toolkit` (for example [here](https://github.com/dan-zam/graph-matching-toolkit)).
* Get the Delaunay Graph Database [here](http://inf.usi.ch/phd/zambon) or generate it as done in the `cdg` demo.
* Run the bash script `ijcnn_xxx.sh`.

The following tree should work out of the box
```
cdg/
scripts/
demo/
graph-matching-toolkit/
|-- graph-matching-toolkit.jar
datasets/
|-- delaunay/
|   |-- 0/
|   |-- 2/
|   |-- 4/
|   |-- 6/
|   |-- 8/
|   |-- 10/
|   |-- 12/
```
