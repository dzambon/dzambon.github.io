#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 25/05/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

CDG_SCRIPTS=$HOME/cdg/scripts 
NO_JOBS=10
DATASET_PATH=./datasets/delaunay
SEED=31012018

# Parameters
REP=100
WIN=1
MANDIM=15
NPROT=30
CN=0
MANIFOLDS=(SphericalDM HyperbolicDM EuclideanDM GraphMu DissRep)
ANOM=(2 4 6 8 10 12)

# Precompute dissimilarities
python3 $CDG_SCRIPTS/prepare_dataset.py -d Delaunay -f $DATASET_PATH -j $NO_JOBS

# Run experiments
for an in "${ANOM[@]}"; do
    for man in "${MANIFOLDS[@]}"; do
        if [ "$man" = "DissRep" ]; then
            NPROT_TMP=$MANDIM
        else
            NPROT_TMP=$NPROT
        fi
		python3 $CDG_SCRIPTS/launch.py -e Delaunay -m $man -r $REP -n $WIN -d $MANDIM -M $NPROT_TMP -N $CN -s $SEED -A $an --setting ijcnn18
	done 
done

# Read results
ls cdgexp_* > exp_list.txt 
python3 $CDG_SCRIPTS/gather_results.py -f exp_list.txt -l tnnls
