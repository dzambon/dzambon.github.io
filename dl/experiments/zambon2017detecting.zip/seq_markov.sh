#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 25/05/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

SUBDATASETS=(1 2 3 4)

# Precompute dissimilarities
for sd in "${SUBDATASETS[@]}"; do
    python3 $CDG_SCRIPTS/prepare_dataset.py -d Markov -f $DATASET_FOLDER/markov -s $sd -j $NO_JOBS 
done 

# Parameters
WIN=32
COMMON_PART="python3 $CDG_SCRIPTS/launch.py -m DissRep -r $REP -s $SEED -e Markov --setting ssci17"

# Number of protiypes
M=4
for ca in "${SUBDATASETS[@]}"; do
    eval $COMMON_PART -n $WIN -M $M -p $ca
done 

# Number of protiypes
M=(1 2 3 4 6 8 10 13 16)
CA=2
for mm in "${M[@]}"; do
    eval $COMMON_PART -n $WIN -M $mm -p $CA
done 


# Window size
M=4
WIN=(10 16 24 36 54 80 120 180 270)
for w in "${WIN[@]}"; do
    eval $COMMON_PART -n $w -M $M -p $CA
done 
