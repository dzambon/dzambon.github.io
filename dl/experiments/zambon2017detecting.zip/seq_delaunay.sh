#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 25/05/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# Precompute dissimilarities
python3 $CDG_SCRIPTS/prepare_dataset.py -d Delaunay812 -f $DATASET_FOLDER/delaunay -j $NO_JOBS 

# Parameters
DATASET=Delaunay
WIN=32
CN=0
CA=11
COMMON_PART="python3 $CDG_SCRIPTS/launch.py -m DissRep -r $REP -s $SEED -N $CN --setting ssci17 -e $DATASET"

# Number of protiypes
M=(1 2 3 4 6 8 10 13 16)
for mm in "${M[@]}"; do
    eval $COMMON_PART -n $WIN -A $CA -M $mm 
done 

# Number of protiypes
M=4
CA=(8 9 10 11 12)
for ca in "${CA[@]}"; do
    eval $COMMON_PART -n $WIN -A $ca -M $M 
done 

# Window size
M=4
CA=11
WIN=(10 16 24 36 54 80 120 180 270)
for w in "${WIN[@]}"; do
    eval $COMMON_PART -n $w -A $CA -M $M
done 
