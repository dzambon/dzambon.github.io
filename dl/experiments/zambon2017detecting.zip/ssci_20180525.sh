#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 25/05/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

CDG_SCRIPTS=$HOME/cdg/scripts 
NO_JOBS=10
SEED=25052018
DATASET_FOLDER=./datasets
REP=100

# Run
source seq_delaunay.sh
source seq_markov.sh

# Read results
ls cdgexp_* > exp_list.txt 
python3 $CDG_SCRIPTS/gather_results.py -f exp_list.txt -l tnnls
