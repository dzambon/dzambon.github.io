Author: *Daniele Zambon*,  
Affiliation: *Università della Svizzera italiana*  
eMail: `daniele.zambon@usi.ch`  
Last Update: *25/05/2018*   


# Experiments of article:  

Zambon, Daniele, Livi, Lorenzo and Alippi, Cesare.   
__Detecting Changes in Sequences of Attributed Graphs.__   
_IEEE Symposium Series in Computational Intelligence_ (2017).    

## Instructions
* Install the `cdg` module available [here](https://github.com/dan-zam/cdg) (works with cdg version 2.0 and python3.)
* If not already present, obtain the `graph-matching-toolkit` (for example [here](https://github.com/dan-zam/graph-matching-toolkit)).
* Get the Delaunay and Markov Graph Database [here](http://inf.usi.ch/phd/zambon) or generate it as done in the `cdg` demo.
* Run the bash script `ssci_xxx.sh`.

The following tree should work out of the box
```
cdg/
scripts/
demo/
graph-matching-toolkit/
|-- graph-matching-toolkit.jar
datasets/
|-- delaunay/
|   |-- 0/
|   |-- 8/
|   |-- 9/
|   |-- 10/
|   |-- 11/
|   |-- 12/
|-- markov/
|   |-- 1/  
|   |   |-- Test/
|   |   |-- Training/
|   |   |-- Validation/
|   |-- 2/
|   |   |-- Test/
|   |   |-- Training/
|   |   |-- Validation/
|   |-- 3/
|   |   |-- Test/
|   |   |-- Training/
|   |   |-- Validation/
|   |-- 4/
|   |   |-- Test/
|   |   |-- Training/
|   |   |-- Validation/
```
