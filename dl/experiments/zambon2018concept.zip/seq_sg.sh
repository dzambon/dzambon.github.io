#!/bin/bash
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 24/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

eval $COMMON_PART -m SpecGap -e Mutagenicity -N nonmutagen 
eval $COMMON_PART -m SpecGap -e AIDS   -N i                
eval $COMMON_PART -m SpecGap -e Letter -N AEFHI -A KLMNT   
eval $COMMON_PART -m SpecGap -e Letter -N AEFH  -A FHIK    
eval $COMMON_PART -m SpecGap -e Letter -N AEFHI -A FHI     
eval $COMMON_PART -m SpecGap -e Letter -N AE    -A FH      
