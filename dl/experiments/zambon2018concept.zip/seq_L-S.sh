#!/bin/bash
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 17/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

DATASET=Letter
CN=AEFHI
CA=FHI

eval $COMMON_PART -e $DATASET -N $CN -A $CA -M 4 -n 5 
eval $COMMON_PART -e $DATASET -N $CN -A $CA -M 4 -n 25 
eval $COMMON_PART -e $DATASET -N $CN -A $CA -M 8 -n 25 
eval $COMMON_PART -e $DATASET -N $CN -A $CA -M 4 -n 125 
eval $COMMON_PART -e $DATASET -N $CN -A $CA -M 8 -n 125 