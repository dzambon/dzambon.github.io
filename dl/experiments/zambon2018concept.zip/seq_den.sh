#!/bin/bash
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 24/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

eval $COMMON_PART -e Mutagenicity -N nonmutagen -m Density
eval $COMMON_PART -e AIDS   -N i                -m Density
eval $COMMON_PART -e Letter -N AEFHI -A KLMNT   -m Density
eval $COMMON_PART -e Letter -N AEFH  -A FHIK    -m Density
eval $COMMON_PART -e Letter -N AEFHI -A FHI     -m Density
eval $COMMON_PART -e Letter -N AE    -A FH      -m Density
