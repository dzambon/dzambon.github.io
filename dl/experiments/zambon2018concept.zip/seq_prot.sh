#!/bin/bash
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 17/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

DATASET=Mutagenicity
CN=nonmutagen
WIN=36 

eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 1
eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 2 
eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 4 
eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 8 
eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 12
eval $COMMON_PART -e $DATASET -N $CN -n $WIN -M 16 
