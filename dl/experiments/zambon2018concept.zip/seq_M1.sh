#!/bin/bash
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 17/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

NPROT=1
WIN=25

eval $COMMON_PART -e Mutagenicity -N nonmutagen -M $NPROT -n $WIN
eval $COMMON_PART -e AIDS   -N i                -M $NPROT -n $WIN
eval $COMMON_PART -e Letter -N AEFHI -A KLMNT   -M $NPROT -n $WIN
eval $COMMON_PART -e Letter -N AEFH  -A FHIK    -M $NPROT -n $WIN
eval $COMMON_PART -e Letter -N AEFHI -A FHI     -M $NPROT -n $WIN
eval $COMMON_PART -e Letter -N AE    -A FH      -M $NPROT -n $WIN