#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Author: Daniele Zambon
# eMail: daniele.zambon@usi.ch
# Last Update: 17/04/2018
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

CDG_SCRIPTS=$HOME/cdg/scripts 
GMT_ABSPATH=$HOME/cdg/graph-matching-toolkit/graph-matching-toolkit.jar
NO_JOBS=10
REP=100
SEED=31012018
DATASET_FOLDER=./datasets

# Precompute dissimilarities
python3 $CDG_SCRIPTS/prepare_dataset.py -d Letter -s HIGH -f $DATASET_FOLDER/iam/Letter -j $NO_JOBS --gmtpath "$GMT_ABSPATH"
python3 $CDG_SCRIPTS/prepare_dataset.py -d AIDS -f $DATASET_FOLDER/iam/AIDS/data -j $NO_JOBS --gmtpath "$GMT_ABSPATH"
python3 $CDG_SCRIPTS/prepare_dataset.py -d Mutagenicity -f $DATASET_FOLDER/iam/Mutagenicity/data -j $NO_JOBS --gmtpath "$GMT_ABSPATH"

# Run experiments
COMMON_PART="python3 $CDG_SCRIPTS/launch.py -m DissRep -r $REP -s $SEED --setting tnnls17"

source seq_A.sh
source seq_L-D2.sh
source seq_L-D5.sh
source seq_L-O.sh
source seq_L-S.sh
source seq_MU.sh
#source seq_prot.sh
source seq_M1.sh

WIN=1
COMMON_PART="python3 $CDG_SCRIPTS/launch.py -r $REP -s $SEED --setting tnnls17"
source seq_den.sh
source seq_sg.sh

# Read results
ls cdgexp_* > exp_list.txt 
python3 $CDG_SCRIPTS/gather_results.py -f exp_list.txt -l tnnls
